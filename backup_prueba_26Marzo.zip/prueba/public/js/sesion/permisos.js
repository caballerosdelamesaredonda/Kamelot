const  admin = [
	{nombre: 'Inicio',link: 'perfil_admin.html'},
	{nombre: 'Listar centros educativos',link: 'listar_centros_educativos.html'},
	{nombre: 'Test',link:'test_link'},
	{nombre: 'Test2',link:'test_link2'}
];

const padre_familia = [
	{nombre: 'Inicio',link: 'perfil_padre_de_familia.html'},
	{nombre: 'Test1',link:'test_link1'},
	{nombre: 'Test2',link:'test_link2'},
	{nombre: 'Test3',link:'test_link3'},
	{nombre: 'Test4',link:'test_link4'}
];

const centro_educativo = [
	{nombre: 'Inicio',link: 'perfil_centro_educativo.html'},
	{nombre: 'Test1',link:'test_link1'},
	{nombre: 'Test2',link:'test_link2'},
	{nombre: 'Test3',link:'test_link3'},
	{nombre: 'Test4',link:'test_link4'}
];