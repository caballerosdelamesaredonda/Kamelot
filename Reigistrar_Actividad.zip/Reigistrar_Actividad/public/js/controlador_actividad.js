'use strict';

const input_actividad = document.querySelector('#txt_actividad');
const boton_registrar = document.querySelector('#btn_registrar');

let actividad = '';

let validar = () => {
    let error = false;

    if(input_actividad.value == ''){
        input_actividad.classList.add('error_input')
        error = true;
    }else{
        input_actividad.classList.remove('error_input')
    };

    return error;

};

let mostrarDatos = () => {

    if (validar() == true) {
        Swal.fire({
            type: 'warning',
            title: 'Validación Incorrecta',
            text: 'Porfavor revise la actividad que desea ingresar'
        })

    }else{
        actividad = text_actividad.value;

        Swal.fire({
            type: 'success',
            title: 'Actividad enviada con éxito',
            text: `En unos segundos se mostrará su nueva activdad en su perfil`    
        })
    }

    

}

boton_registrar.addEventListener('click', mostrarDatos);