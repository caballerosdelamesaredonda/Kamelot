'use strict';
const model_actividad = require('./actividad.model');


module.exports.registrar = (req, res) =>{
    let actividad_nueva = new model_actividad(
        {
            actividad : req.body.actividad
        }
    );
};


module.exports.listar_todos = (req ,res) =>{
    model_actividad.find().then(
        function(actividad){
            if(actividad.length > 0){
                res.json(
                    {
                        success: true,
                        actividad: actividad
                    }
                )
            }else{
                res.json(
                    {
                        success: false,
                        actividad: 'No se encontraron comentarios'
                    }
                )
            }
        }

    )
};