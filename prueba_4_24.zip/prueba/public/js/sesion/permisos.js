let menu_admin = document.createElement('ul');


//nombres de dropdown
let ce = document.createElement('li');
let reportes = document.createElement('li');


// opciones ce
let opcion_listar_ce = document.createElement('a');
opcion_listar_ce.href = "listar_centroe.html";


// opciones reportes
let opcion_ranking_ce = document.createElement('a');
opcion_ranking_ce.href = "reporte_ranking_ce.html";
opcion_ranking_ce.innerHTML = "Ranking centros educativos";






const padre_familia = [
	{nombre: 'Inicio',link: 'perfil_padre_de_familia.html'},
	{nombre: 'Test1',link:'test_link1'},
	{nombre: 'Test2',link:'test_link2'},
	{nombre: 'Test3',link:'test_link3'},
	{nombre: 'Test4',link:'test_link4'}
];

const centro_educativo = [
	{nombre: 'Inicio',link: 'perfil_centro_educativo.html'},
	{nombre: 'Test1',link:'test_link1'},
	{nombre: 'Test2',link:'test_link2'},
	{nombre: 'Test3',link:'test_link3'},
	{nombre: 'Test4',link:'test_link4'}
];


